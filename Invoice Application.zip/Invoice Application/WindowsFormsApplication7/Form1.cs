﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

 namespace Invoice_Application
{
    public partial class Invoice_Application : Form
    {
        //Global Variable
        int customerCount = 0;
        
       
        public Invoice_Application()
        {
            InitializeComponent();
            
        }

 

        customer_details[] customerDetails = new customer_details[1000]; 

        private void addbutton_Click(object sender, EventArgs e)
        {

           if (customerCount > 1000)
            {
                MessageBox.Show("You have reached the maximum amount of customers.");
                
            }
           else
            {
                customerDetails[customerCount] = new customer_details();
                customerDetails[customerCount].CustomerName = txt_customername.Text;
                customerDetails[customerCount].Address = txt_address.Text;
                customerDetails[customerCount].CustomerNumber = txt_customernumber.Text;
                customerDetails[customerCount].ContactNumber = txt_contactnumber.Text;
                customerCount++;          
            }
        }

        private void btn_Search_Click(object sender, EventArgs e)
        {

            for (int i = 0; i < customerCount; i++)
            {
                if (txt_customername.Text == customerDetails[i].CustomerName)
                {
                    // i is your array location / customerid
                    listBox.Items.Add(customerDetails[i].CustomerName);
                    listBox.Items.Add(customerDetails[i].Address);
                    listBox.Items.Add(customerDetails[i].CustomerNumber);
                    listBox.Items.Add(customerDetails[i].ContactNumber);
                }
                else
                {
                    MessageBox.Show("User is not existed. Please enter valid user!");
                }
            }
        }


                 private void btn_Edit_Click(object sender, EventArgs e)
        {
                
                if (!string.IsNullOrEmpty(txt_customername.Text) && !string.IsNullOrEmpty(txt_address.Text))
                {
                    customerDetails[customerCount].CustomerName = txt_customername.Text;
                    customerDetails[customerCount].Address = txt_address.Text;
                }
            
        }

    

        private void Invoice_Application_Load(object sender, EventArgs e)
        {

        }

        private void descriptiontxtBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox_Click(object sender, EventArgs e)
        {
            
        }

        private void browsebutton_Click(object sender, EventArgs e)
        {
            OpenFileDialog newDialog = new OpenFileDialog();
            if (newDialog.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    pictureBox.Load(newDialog.FileName);
                    pictureBox.SizeMode = PictureBoxSizeMode.Zoom;
                }
                catch
                {
                    MessageBox.Show("Wrong file type!", "Error");
                }
            }
        }

        private void firstname_Click(object sender, EventArgs e)
        {

        }

       
    }
}
