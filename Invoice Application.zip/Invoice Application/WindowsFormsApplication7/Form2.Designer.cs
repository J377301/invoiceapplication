﻿namespace Invoice_Application
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.loginid = new System.Windows.Forms.Label();
            this.loginidtxtBox = new System.Windows.Forms.TextBox();
            this.password = new System.Windows.Forms.Label();
            this.passwordtxtBox = new System.Windows.Forms.TextBox();
            this.Login = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // loginid
            // 
            this.loginid.AutoSize = true;
            this.loginid.Location = new System.Drawing.Point(27, 42);
            this.loginid.Name = "loginid";
            this.loginid.Size = new System.Drawing.Size(47, 13);
            this.loginid.TabIndex = 0;
            this.loginid.Text = "Login ID";
            this.loginid.Click += new System.EventHandler(this.label1_Click);
            // 
            // loginidtxtBox
            // 
            this.loginidtxtBox.Location = new System.Drawing.Point(130, 42);
            this.loginidtxtBox.Name = "loginidtxtBox";
            this.loginidtxtBox.Size = new System.Drawing.Size(110, 20);
            this.loginidtxtBox.TabIndex = 1;
            // 
            // password
            // 
            this.password.AutoSize = true;
            this.password.Location = new System.Drawing.Point(27, 98);
            this.password.Name = "password";
            this.password.Size = new System.Drawing.Size(53, 13);
            this.password.TabIndex = 2;
            this.password.Text = "Password";
            // 
            // passwordtxtBox
            // 
            this.passwordtxtBox.Location = new System.Drawing.Point(130, 91);
            this.passwordtxtBox.Name = "passwordtxtBox";
            this.passwordtxtBox.Size = new System.Drawing.Size(110, 20);
            this.passwordtxtBox.TabIndex = 3;
            // 
            // Login
            // 
            this.Login.Location = new System.Drawing.Point(104, 156);
            this.Login.Name = "Login";
            this.Login.Size = new System.Drawing.Size(75, 23);
            this.Login.TabIndex = 4;
            this.Login.Text = "Login";
            this.Login.UseVisualStyleBackColor = true;
            this.Login.Click += new System.EventHandler(this.Login_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(288, 211);
            this.Controls.Add(this.Login);
            this.Controls.Add(this.passwordtxtBox);
            this.Controls.Add(this.password);
            this.Controls.Add(this.loginidtxtBox);
            this.Controls.Add(this.loginid);
            this.Name = "Form2";
            this.Text = "Invoice Application";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label loginid;
        private System.Windows.Forms.TextBox loginidtxtBox;
        private System.Windows.Forms.Label password;
        private System.Windows.Forms.TextBox passwordtxtBox;
        private System.Windows.Forms.Button Login;
    }
}