﻿namespace Invoice_Application
{
    partial class Invoice_Application
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Customer_Details = new System.Windows.Forms.Label();
            this.lbl_customername = new System.Windows.Forms.Label();
            this.txt_customername = new System.Windows.Forms.TextBox();
            this.address = new System.Windows.Forms.Label();
            this.txt_address = new System.Windows.Forms.TextBox();
            this.lbl_contactnumber = new System.Windows.Forms.Label();
            this.txt_contactnumber = new System.Windows.Forms.TextBox();
            this.invoicenumber = new System.Windows.Forms.Label();
            this.txt_customernumber = new System.Windows.Forms.TextBox();
            this.invoicedetails = new System.Windows.Forms.Label();
            this.btn_add = new System.Windows.Forms.Button();
            this.cancelbutton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.cus_numtxtBox = new System.Windows.Forms.TextBox();
            this.invoice_number = new System.Windows.Forms.Label();
            this.invoice_numbertxtBox = new System.Windows.Forms.TextBox();
            this.c = new System.Windows.Forms.Label();
            this.descriptiontxtBox = new System.Windows.Forms.RichTextBox();
            this.cost = new System.Windows.Forms.Label();
            this.costtxtBox = new System.Windows.Forms.TextBox();
            this.paymentdate = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.pictureBox = new System.Windows.Forms.PictureBox();
            this.browsebutton = new System.Windows.Forms.Button();
            this.btn_Edit = new System.Windows.Forms.Button();
            this.btn_Search = new System.Windows.Forms.Button();
            this.listBox = new System.Windows.Forms.ListBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // Customer_Details
            // 
            this.Customer_Details.AutoSize = true;
            this.Customer_Details.BackColor = System.Drawing.SystemColors.Highlight;
            this.Customer_Details.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Customer_Details.Enabled = false;
            this.Customer_Details.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Customer_Details.Location = new System.Drawing.Point(104, 36);
            this.Customer_Details.Name = "Customer_Details";
            this.Customer_Details.Size = new System.Drawing.Size(178, 27);
            this.Customer_Details.TabIndex = 0;
            this.Customer_Details.Text = "Customer Details";
            // 
            // lbl_customername
            // 
            this.lbl_customername.AutoSize = true;
            this.lbl_customername.Location = new System.Drawing.Point(24, 104);
            this.lbl_customername.Name = "lbl_customername";
            this.lbl_customername.Size = new System.Drawing.Size(82, 13);
            this.lbl_customername.TabIndex = 3;
            this.lbl_customername.Text = "Customer Name";
            this.lbl_customername.Click += new System.EventHandler(this.firstname_Click);
            // 
            // txt_customername
            // 
            this.txt_customername.Location = new System.Drawing.Point(151, 101);
            this.txt_customername.Name = "txt_customername";
            this.txt_customername.Size = new System.Drawing.Size(218, 20);
            this.txt_customername.TabIndex = 4;
            // 
            // address
            // 
            this.address.AutoSize = true;
            this.address.Location = new System.Drawing.Point(24, 138);
            this.address.Name = "address";
            this.address.Size = new System.Drawing.Size(45, 13);
            this.address.TabIndex = 7;
            this.address.Text = "Address";
            // 
            // txt_address
            // 
            this.txt_address.Location = new System.Drawing.Point(151, 141);
            this.txt_address.Name = "txt_address";
            this.txt_address.Size = new System.Drawing.Size(218, 20);
            this.txt_address.TabIndex = 8;
            // 
            // lbl_contactnumber
            // 
            this.lbl_contactnumber.AutoSize = true;
            this.lbl_contactnumber.Location = new System.Drawing.Point(24, 238);
            this.lbl_contactnumber.Name = "lbl_contactnumber";
            this.lbl_contactnumber.Size = new System.Drawing.Size(84, 13);
            this.lbl_contactnumber.TabIndex = 9;
            this.lbl_contactnumber.Text = "Contact Number";
            // 
            // txt_contactnumber
            // 
            this.txt_contactnumber.Location = new System.Drawing.Point(151, 238);
            this.txt_contactnumber.Name = "txt_contactnumber";
            this.txt_contactnumber.Size = new System.Drawing.Size(218, 20);
            this.txt_contactnumber.TabIndex = 10;
            // 
            // invoicenumber
            // 
            this.invoicenumber.AutoSize = true;
            this.invoicenumber.Location = new System.Drawing.Point(24, 187);
            this.invoicenumber.Name = "invoicenumber";
            this.invoicenumber.Size = new System.Drawing.Size(91, 13);
            this.invoicenumber.TabIndex = 13;
            this.invoicenumber.Text = "Customer Number";
            // 
            // txt_customernumber
            // 
            this.txt_customernumber.Location = new System.Drawing.Point(151, 187);
            this.txt_customernumber.Name = "txt_customernumber";
            this.txt_customernumber.Size = new System.Drawing.Size(218, 20);
            this.txt_customernumber.TabIndex = 14;
            // 
            // invoicedetails
            // 
            this.invoicedetails.AutoSize = true;
            this.invoicedetails.BackColor = System.Drawing.SystemColors.Highlight;
            this.invoicedetails.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.invoicedetails.Enabled = false;
            this.invoicedetails.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.invoicedetails.Location = new System.Drawing.Point(580, 18);
            this.invoicedetails.Name = "invoicedetails";
            this.invoicedetails.Size = new System.Drawing.Size(154, 27);
            this.invoicedetails.TabIndex = 17;
            this.invoicedetails.Text = "Invoice Details";
            // 
            // btn_add
            // 
            this.btn_add.Location = new System.Drawing.Point(57, 292);
            this.btn_add.Name = "btn_add";
            this.btn_add.Size = new System.Drawing.Size(75, 23);
            this.btn_add.TabIndex = 18;
            this.btn_add.Text = "Add";
            this.btn_add.UseVisualStyleBackColor = true;
            this.btn_add.Click += new System.EventHandler(this.addbutton_Click);
            // 
            // cancelbutton
            // 
            this.cancelbutton.Location = new System.Drawing.Point(614, 385);
            this.cancelbutton.Name = "cancelbutton";
            this.cancelbutton.Size = new System.Drawing.Size(75, 23);
            this.cancelbutton.TabIndex = 19;
            this.cancelbutton.Text = "Cancel";
            this.cancelbutton.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(513, 67);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(91, 13);
            this.label1.TabIndex = 20;
            this.label1.Text = "Customer Number";
            // 
            // cus_numtxtBox
            // 
            this.cus_numtxtBox.Location = new System.Drawing.Point(646, 67);
            this.cus_numtxtBox.Name = "cus_numtxtBox";
            this.cus_numtxtBox.Size = new System.Drawing.Size(218, 20);
            this.cus_numtxtBox.TabIndex = 21;
            // 
            // invoice_number
            // 
            this.invoice_number.AutoSize = true;
            this.invoice_number.Location = new System.Drawing.Point(513, 104);
            this.invoice_number.Name = "invoice_number";
            this.invoice_number.Size = new System.Drawing.Size(82, 13);
            this.invoice_number.TabIndex = 22;
            this.invoice_number.Text = "Invoice Number";
            // 
            // invoice_numbertxtBox
            // 
            this.invoice_numbertxtBox.Location = new System.Drawing.Point(646, 101);
            this.invoice_numbertxtBox.Name = "invoice_numbertxtBox";
            this.invoice_numbertxtBox.Size = new System.Drawing.Size(218, 20);
            this.invoice_numbertxtBox.TabIndex = 23;
            // 
            // c
            // 
            this.c.AutoSize = true;
            this.c.Location = new System.Drawing.Point(513, 138);
            this.c.Name = "c";
            this.c.Size = new System.Drawing.Size(60, 13);
            this.c.TabIndex = 24;
            this.c.Text = "Description";
            // 
            // descriptiontxtBox
            // 
            this.descriptiontxtBox.Location = new System.Drawing.Point(646, 141);
            this.descriptiontxtBox.Name = "descriptiontxtBox";
            this.descriptiontxtBox.Size = new System.Drawing.Size(218, 101);
            this.descriptiontxtBox.TabIndex = 25;
            this.descriptiontxtBox.Text = "";
            this.descriptiontxtBox.TextChanged += new System.EventHandler(this.descriptiontxtBox_TextChanged);
            // 
            // cost
            // 
            this.cost.AutoSize = true;
            this.cost.Location = new System.Drawing.Point(513, 261);
            this.cost.Name = "cost";
            this.cost.Size = new System.Drawing.Size(28, 13);
            this.cost.TabIndex = 26;
            this.cost.Text = "Cost";
            // 
            // costtxtBox
            // 
            this.costtxtBox.Location = new System.Drawing.Point(646, 261);
            this.costtxtBox.Name = "costtxtBox";
            this.costtxtBox.Size = new System.Drawing.Size(218, 20);
            this.costtxtBox.TabIndex = 27;
            // 
            // paymentdate
            // 
            this.paymentdate.AutoSize = true;
            this.paymentdate.Location = new System.Drawing.Point(513, 297);
            this.paymentdate.Name = "paymentdate";
            this.paymentdate.Size = new System.Drawing.Size(74, 13);
            this.paymentdate.TabIndex = 28;
            this.paymentdate.Text = "Payment Date";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(646, 297);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker1.TabIndex = 29;
            // 
            // pictureBox
            // 
            this.pictureBox.Image = global::WindowsFormsApplication7.Properties.Resources.Chrysanthemum;
            this.pictureBox.Location = new System.Drawing.Point(-1, 1);
            this.pictureBox.Name = "pictureBox";
            this.pictureBox.Size = new System.Drawing.Size(930, 445);
            this.pictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox.TabIndex = 30;
            this.pictureBox.TabStop = false;
            this.pictureBox.Click += new System.EventHandler(this.pictureBox_Click);
            // 
            // browsebutton
            // 
            this.browsebutton.Location = new System.Drawing.Point(707, 385);
            this.browsebutton.Name = "browsebutton";
            this.browsebutton.Size = new System.Drawing.Size(184, 23);
            this.browsebutton.TabIndex = 31;
            this.browsebutton.Text = "Change Background Picture";
            this.browsebutton.UseVisualStyleBackColor = true;
            this.browsebutton.Click += new System.EventHandler(this.browsebutton_Click);
            // 
            // btn_Edit
            // 
            this.btn_Edit.Location = new System.Drawing.Point(151, 292);
            this.btn_Edit.Name = "btn_Edit";
            this.btn_Edit.Size = new System.Drawing.Size(75, 23);
            this.btn_Edit.TabIndex = 32;
            this.btn_Edit.Text = "Edit";
            this.btn_Edit.UseVisualStyleBackColor = true;
            this.btn_Edit.Click += new System.EventHandler(this.btn_Edit_Click);
            // 
            // btn_Search
            // 
            this.btn_Search.Location = new System.Drawing.Point(245, 292);
            this.btn_Search.Name = "btn_Search";
            this.btn_Search.Size = new System.Drawing.Size(75, 23);
            this.btn_Search.TabIndex = 33;
            this.btn_Search.Text = "Search";
            this.btn_Search.UseVisualStyleBackColor = true;
            this.btn_Search.Click += new System.EventHandler(this.btn_Search_Click);
            // 
            // listBox
            // 
            this.listBox.FormattingEnabled = true;
            this.listBox.Location = new System.Drawing.Point(151, 339);
            this.listBox.Name = "listBox";
            this.listBox.Size = new System.Drawing.Size(226, 186);
            this.listBox.TabIndex = 34;
            // 
            // Invoice_Application
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(991, 571);
            this.Controls.Add(this.listBox);
            this.Controls.Add(this.btn_Search);
            this.Controls.Add(this.btn_Edit);
            this.Controls.Add(this.browsebutton);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.paymentdate);
            this.Controls.Add(this.costtxtBox);
            this.Controls.Add(this.cost);
            this.Controls.Add(this.descriptiontxtBox);
            this.Controls.Add(this.c);
            this.Controls.Add(this.invoice_numbertxtBox);
            this.Controls.Add(this.invoice_number);
            this.Controls.Add(this.cus_numtxtBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cancelbutton);
            this.Controls.Add(this.btn_add);
            this.Controls.Add(this.invoicedetails);
            this.Controls.Add(this.txt_customernumber);
            this.Controls.Add(this.invoicenumber);
            this.Controls.Add(this.txt_contactnumber);
            this.Controls.Add(this.lbl_contactnumber);
            this.Controls.Add(this.txt_address);
            this.Controls.Add(this.address);
            this.Controls.Add(this.txt_customername);
            this.Controls.Add(this.lbl_customername);
            this.Controls.Add(this.Customer_Details);
            this.Controls.Add(this.pictureBox);
            this.Name = "Invoice_Application";
            this.Text = "Invoice Application";
            this.Load += new System.EventHandler(this.Invoice_Application_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Customer_Details;
        private System.Windows.Forms.Label lbl_customername;
        private System.Windows.Forms.TextBox txt_customername;
        private System.Windows.Forms.Label address;
        private System.Windows.Forms.TextBox txt_address;
        private System.Windows.Forms.Label lbl_contactnumber;
        private System.Windows.Forms.TextBox txt_contactnumber;
        private System.Windows.Forms.Label invoicenumber;
        private System.Windows.Forms.TextBox txt_customernumber;
        private System.Windows.Forms.Label invoicedetails;
        private System.Windows.Forms.Button btn_add;
        private System.Windows.Forms.Button cancelbutton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox cus_numtxtBox;
        private System.Windows.Forms.Label invoice_number;
        private System.Windows.Forms.TextBox invoice_numbertxtBox;
        private System.Windows.Forms.Label c;
        private System.Windows.Forms.RichTextBox descriptiontxtBox;
        private System.Windows.Forms.Label cost;
        private System.Windows.Forms.TextBox costtxtBox;
        private System.Windows.Forms.Label paymentdate;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.PictureBox pictureBox;
        private System.Windows.Forms.Button browsebutton;
        private System.Windows.Forms.Button btn_Edit;
        private System.Windows.Forms.Button btn_Search;
        private System.Windows.Forms.ListBox listBox;
    }
}

