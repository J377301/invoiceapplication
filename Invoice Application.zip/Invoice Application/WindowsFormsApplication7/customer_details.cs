﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Invoice_Application
{
    public class customer_details
    {

        public customer_details () { }

        public customer_details(string CustomerName, string Address, string CustomerNumber, string ContactNumber)
        {
            CustomerName = "";
            Address = "";
            CustomerNumber = "";
            ContactNumber = ""; 

        }

        public string CustomerName { get; set; }
        public string Address { get; set; }
        public string CustomerNumber { get; set; }
        public string ContactNumber { get; set; }

    }
}
